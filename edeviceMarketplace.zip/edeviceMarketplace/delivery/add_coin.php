<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "greenurban";
$uid = $_POST['uid'];
$expense = $_POST['expense'];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, balance FROM usersmeta WHERE uid =$uid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $mid = $row["id"];
   echo $data = $row["balance"];
  }
} else {
  echo "0 results";
}

//////////////////////////////////////////////
echo $bal = (int)$expense + $data;

// $bal =  $expense + $data;
$sql2 ="UPDATE `usersmeta` SET `balance` = '$bal' WHERE `usersmeta`.`id` = '$mid'";
if ($conn->query($sql2) === TRUE) {
  echo '<script>alert("Balance credited to user account completed  ")</script>';
  header('Location: service.php');
}
 else 
{
  echo "Error: " . $sql2 . "<br>" . $conn->error;
}
///////////////////////////////////////////////////Balance credited to user account completed 
$conn->close();
?>
