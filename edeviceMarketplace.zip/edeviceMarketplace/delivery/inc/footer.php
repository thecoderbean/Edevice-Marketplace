	<div class="clearfix space70"></div>
	<!-- FOOTER -->
	<footer id="footer2">
		
		<div class="footer-bottom container">
			<div class="row">
				<div class="col-md-6">
					<p>&copy; Copyright 2023. bestin_s_jorly</p>
				</div>
				<div class="col-md-6">
					
				</div>
			</div>
		</div>
	</footer>
	<!-- FOOTER -->
</div>
<!-- Javascript -->
<script src="../shopping/js/jquery.min.js"></script>
<script src="../shopping/js/bootstrap.min.js"></script>
<script src="../shopping/js/dialogFx.js"></script>
<script src="../shopping/js/dialog-js.js"></script>
<script src="../shopping/js/navigation/jquery.easing.js"></script>
<script src="../shopping/js/flexslider/jquery.flexslider.js"></script>
<script src="../shopping/js/navigation/scroll.js"></script>
<script src="../shopping/js/navigation/jquery.sticky.js"></script>
<script src="../shopping/js/owl-carousel/owl.carousel.min.js"></script>
<script src="../shopping/js/isotope/isotope.pkgd.js"></script>
<script src="../shopping/js/superfish/js/hoverIntent.js"></script>
<script src="../shopping/js/superfish/js/superfish.js"></script>
<script src="../shopping/js/tweecool.js"></script>
<script src="../shopping/js/jquery.bpopup.js"></script>
<script src="../shopping/js/pikaday/pikaday.js"></script>
<script src="../shopping/js/classie.js"></script>
<script src="../shopping/http://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<script src="../shopping/js/rs-plugin/js/jquery.themepunch.tools.min.js"></script>   
<script src="../shopping/js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script src="../shopping/js/jquery.prettyphoto.js"></script>
<script src="../shopping/js/script.js"></script>
<script src="../shopping/js/booking.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script src="../shopping/js/gmap.js"></script>
<script src="../shopping/js/gmap2.js"></script>


</body>
</html>