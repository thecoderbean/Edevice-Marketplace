			<div class="menu-wrap">
				<div id="mobnav-btn">Menu <i class="fa fa-bars"></i></div>
				<ul class="sf-menu">
					<li>
						<a href="home.php">Home</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
					</li>
					<li>
						<li><a href="order.php">Orders</a></li>
					</li>
					<li>
						<li><a href="pickup.php">Pickup</a></li>
					</li>
					<li>
						<a href="#">My Account</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
					    	<li><a href="logout.php">Logout</a></li>
						</ul>
					</li>
				</ul>
				<div class="header-xtra">
					
				</div>
			</div>
		</div>
	</header>